export const MenuDonors = [
  {
    _id: 1,
    title: "Donate Food",
    path: "/post",
    cName: "dropdown-link",
  },
  {
    _id: 2,
    title: "Donate Funds",
    path: "/donation",
    cName: "dropdown-link",
  },
  {
    _id: 3,
    title: "Inventory",
    path: "/itemList",
    cName: "dropdown-link",
  },
  {
    _id: 4,
    title: "Other ways to help",
    path: "/other",
    cName: "dropdown-link",
  },
];
