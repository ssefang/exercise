export const sliderItems = [
    {
        _id:1,
        image:"/images/slider/1.jpg"
    },
    {
        _id:2,
        image:"/images/slider/2.jpg"
    },
    {
        _id:3,
        image:"/images/slider/3.jpg"
    },
];

export const category = [
    {
        _id:1,
        title:"motivation",
        image:"/images/category/1.png"
    },
    {
        _id:2,
        title:"team",
        image:"/images/category/2.png"
    },
    {
        _id:3,
        title:"goal",
        image:"/images/category/3.png"
    },
];
