import React from 'react';

export default function Kids(){

    return(
        <>
            <h1 className = 'kids'>Meals for kids</h1>
        
        </>
    )

}