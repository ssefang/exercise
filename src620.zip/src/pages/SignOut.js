import React from 'react';

import LoginForm from './LoginForm';


const SignOut = () => {
    

    return (
       <>
       <h1>Bye</h1>
       <LoginForm />
       </>
    )
}

export default SignOut;