import React from "react";
import GrabberPortalList from "../components/GrabberPortalList";

const GrabberPortal = () => {
  return (
    <div>
      {/* <Navbar /> */}
      <GrabberPortalList />
      {/* <Footer /> */}
    </div>
  );
};

export default GrabberPortal;
