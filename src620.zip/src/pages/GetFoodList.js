import React from "react";
import FullItemList from "../components/FullItemList";

const About = () => {
  return (
    <div>
      {/* <Navbar /> */}
      <FullItemList />
      {/* <Footer /> */}
    </div>
  );
};

export default About;
