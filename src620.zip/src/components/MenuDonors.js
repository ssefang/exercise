export const MenuDonors = [
    {
      _id: 1,
      title: 'Dashboard',
      path: '/itemList',
      cName: 'dropdown-link'
    },
    {
      _id: 2,
      title: 'Donations',
      path: '/kids',
      cName: 'dropdown-link'
    },
    {
      _id: 3,
      title: 'Volunteers ',
      path: '/nutrition',
      cName: 'dropdown-link'
    },
    {
      _id: 4,
      title: 'Other ways to help',
      path: '/development',
      cName: 'dropdown-link'
    }
  ];