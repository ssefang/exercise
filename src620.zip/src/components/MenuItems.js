export const MenuItems = [
  {
    _id: 1,
    title: 'GetFood',
    path: '/getfood',
    cName: 'dropdown-link'
  },
  {
    _id: 2,
    title: 'Meals for kids',
    path: '/kids',
    cName: 'dropdown-link'
  },
  {
    _id: 3,
    title: 'Nutrition Center',
    path: '/nutrition',
    cName: 'dropdown-link'
  },
  {
    _id: 4,
    title: 'Development',
    path: '/development',
    cName: 'dropdown-link'
  }
];