import React from "react";
import { Button } from "react-bootstrap";

function About() {
  return (
    <div>
      <h1>About page</h1>
      <Button variant="primary">about</Button>
    </div>
  );
}

export default About;
