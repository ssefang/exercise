import React from "react";

function Dashboard() {
  return (
    <div>
      <h1>dashboard page</h1>
    </div>
  );
}

export default Dashboard;
