import React from "react";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";

import Dashboard from "./pages/Dashboard";
import About from "./pages/About";
import Post from "./pages/Post";
import ItemList from "./pages/ItemList";
import Home from "./pages/Home";
import SidebarLayout from "./layouts/SidebarLayout";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/home" exact element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route element={<SidebarLayout />}>
          <Route path="/about" element={<About />} />
          <Route path="/post" element={<Post />} />
          <Route path="/itemList" element={<ItemList />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default App;
